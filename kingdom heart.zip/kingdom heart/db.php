<?php
try {
    $pdo = new PDO('mysql:host=localhost;dbname=kingdom_hearts;charset=utf8', 'root', '');
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    die("Erreur de connexion : " . $e->getMessage()); // [cite: 2609, 2792]
}
?>