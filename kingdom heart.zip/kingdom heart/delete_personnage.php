<?php 
require 'db.php';

if (isset($_GET['id'])) {
    $stmt = $pdo->prepare("DELETE FROM personnages WHERE id = ?");
    $stmt->execute([$_GET['id']]);
}
header('Location: admin_personnages.php');
?>