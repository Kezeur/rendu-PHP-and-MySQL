<?php 
require 'db.php';
$id = $_GET['id'];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $stmt = $pdo->prepare("UPDATE personnages SET nom = :nom, description = :desc WHERE id = :id");
    $stmt->execute([
        'nom' => $_POST['nom'],
        'desc' => $_POST['description'],
        'id' => $id
    ]);
    header('Location: admin_personnages.php');
}

$stmt = $pdo->prepare("SELECT * FROM personnages WHERE id = ?");
$stmt->execute([$id]);
$p = $stmt->fetch(PDO::FETCH_ASSOC);
?>

<form method="POST">
    <input type="text" name="nom" value="<?= $p['nom'] ?>">
    <textarea name="description"><?= $p['description'] ?></textarea>
    <button type="submit">Mettre à jour</button>
</form>