<?php 
require 'db.php';


if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['ajouter'])) {
    $stmt = $pdo->prepare("INSERT INTO personnages (nom, description) VALUES (:nom, :desc)");
    $stmt->execute([
        'nom' => $_POST['nom'],
        'desc' => $_POST['description']
    ]);
}


$personnages = $pdo->query("SELECT * FROM personnages")->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Admin - Kingdom Hearts</title>
    <link rel="stylesheet" href="style.css">
</head>
<body class="light-mode">
    <h1>Gestion des Personnages</h1>

    <form method="POST" style="margin: 20px;">
        <input type="text" name="nom" placeholder="Nom du personnage" required>
        <textarea name="description" placeholder="Description"></textarea>
        <button type="submit" name="ajouter">Ajouter</button>
    </form>

    <hr>

    <ul>
        <?php foreach ($personnages as $p): ?>
            <li>
                <strong><?= htmlspecialchars($p['nom']) ?></strong> - 
                <a href="edit_personnage.php?id=<?= $p['id'] ?>">Modifier</a> | 
                <a href="delete_personnage.php?id=<?= $p['id'] ?>" onclick="return confirm('Supprimer ?')">Supprimer</a>
            </li>
        <?php endforeach; ?>
    </ul>
    <a href="index.html">Retour au site</a>
</body>
</html>